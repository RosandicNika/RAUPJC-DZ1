﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1_Task2
{
    public interface IGenericList<X>
    {
        /// <summary >
        /// Adds an item to the collection .
        /// </ summary >
        void Add(X item);
        /// <summary >
        /// Removes the first occurrence of an item from the collection .
        /// If the item was not found , method does nothing .
        /// </ summary >
        bool Remove(X item);
        /// <summary >
        /// Removes the item at the given index in the collection .
        /// </ summary >
        bool RemoveAt(int index);
        /// <summary >
        /// Returns the item at the given index in the collection .
        /// </ summary >
        X GetElement(int index);
        /// <summary >
        /// Returns the index of the item in the collection .
        /// If item is not found in the collection , method returns -1.
        /// </ summary >
        int IndexOf(X item);
        /// <summary >
        /// Readonly property . Gets the number of items contained in the
        ///collection.
        /// </ summary >
        int Count { get; }
        /// <summary >
        /// Removes all items from the collection .
        /// </ summary >
        void Clear();
        /// <summary >
        /// Determines whether the collection contains a specific value .
        /// </ summary >
        bool Contains(X item);
    }
}
    public class NegativeSizeException : Exception
    {
        public NegativeSizeException(string message)
        {
            Console.WriteLine("%s", message);
        }
    }


    public class IntegerList : IIntegerList
    {
        private int[] _internalStorage;
        int size = 0;

        /// <summary>
        /// A constructor that initializes a 4 element array
        /// </summary>
        public IntegerList()
        {
            _internalStorage = new int[4];
        }

        /// <summary>
        /// A constructor that initializes an array to an "initialSize" number of elements
        /// </summary>
        /// <param name="initialSize"></param>
        public IntegerList(int initialSize)
        {
            if (initialSize < 0)
            {
                throw new NegativeSizeException("Size of an array cannot be a negative value.");
            }
            else
            {
                _internalStorage = new int[initialSize];
            }
        }

        public void Add(int item)
        {
            if (_internalStorage.Length == size)
            {
                Array.Resize(ref _internalStorage, _internalStorage.Length * 2);
            }
            _internalStorage[size] = item;
            ++size;
        }

        public bool RemoveAt(int index)
        {
            if (index >= size)
            {
                return false;
            }
            else
            {
                for (int i = index; i < size; i++)
                {
                    _internalStorage[i] = _internalStorage[i + 1];
                }
                _internalStorage[size - 1] = 0;
                --size;
                return true;
            }
        }

        public bool Remove(int item)
        {

            int index = 0;
            for (int i = 0; i < size; ++i)
            {
                if (_internalStorage[i] == item)
                {
                    index = i;
                    return RemoveAt(index);
                }
            }
            return false;
        }

        public int GetElement(int index)
        {
            if (index < size && index > 0)
            {
                return _internalStorage[index];

            }
            else
            {
                throw new IndexOutOfRangeException();
            }
        }

        public int Count
        {
            get
            {
                return size;
            }

        }

        public int IndexOf(int item)
        {
            int index = -1;
            for (int i = 0; i < size; i++)
            {
                if (_internalStorage[i] == item)
                {
                    index = i;
                }
            }
            return index;
        }

        public void Clear()
        {
            Array.Clear(_internalStorage, 0, _internalStorage.Length);
            size = 0;
        }

        public bool Contains(int item)
        {
            for (int i = 0; i < size; i++)
            {
                if (_internalStorage[i] == item)
                {
                    return true;
                }
            }
            return false;
        }
    }


    ///<summary
    ///An example of the use of our implemented list.
    ///</summary
    class ListExample
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Enter array size:");
            //string line1 = Console.ReadLine();
            //int size = Int32.Parse(line1);
            IntegerList listOfIntegers = new IntegerList();
            listOfIntegers.Add(1); // [1]
            listOfIntegers.Add(2); // [1 ,2]
            listOfIntegers.Add(3); // [1 ,2 ,3]
            listOfIntegers.Add(4); // [1 ,2 ,3 ,4]
            listOfIntegers.Add(5); // [1 ,2 ,3 ,4 ,5]
            listOfIntegers.RemoveAt(0); // [2 ,3 ,4 ,5]
            listOfIntegers.Remove(5); //[2 ,3 ,4]
            Console.WriteLine(listOfIntegers.Count); // 3
            Console.WriteLine(listOfIntegers.Contains(1)); // false
            Console.WriteLine(listOfIntegers.RemoveAt(5)); // false
            listOfIntegers.Clear(); // []
            Console.WriteLine(listOfIntegers.Count); // 0
            Console.ReadLine();
        }
    }
}